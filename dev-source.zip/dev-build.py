#!/usr/bin/env python3
"""يبني ملفات النشر:  python3 dev-build.py   (كل الملفات في مجلد واحد بلا مجلدات فرعية)
 المدخلات : dev-app.html + dev-sw.template.js + ملفات js/css
 المخرجات : index.html, sw.js, build.json, version.json
 لكل ملف js/css بصمة محتواه (?h=) فلا يُعاد تنزيل إلا ما تغيّر؛ BID = بصمة الكل."""
import re, os, json, hashlib, glob
ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)
app = open('dev-app.html', encoding='utf-8').read()
sw = open('dev-sw.template.js', encoding='utf-8').read()
assets = []
for m in re.finditer(r'(?:src|href)="([A-Za-z0-9_.\-]+\.(?:js|css))\?h=__BID__"', app):
    if m.group(1) not in assets: assets.append(m.group(1))
STATIC = ['ic-192.png', 'ic-512.png']
SOFT = ['bg-%d-t.jpg' % i for i in range(1, 15)] + ['adhan-libya-takbeer.mp3', 'adhan-makkah-takbeer.mp3', 'adhan-qatami-takbeer.mp3']
fh = {}
for f in assets + ['manifest.json'] + STATIC + SOFT:
    fh[f] = hashlib.sha1(open(f, 'rb').read()).hexdigest()[:10]
index = app
def hname(f):                      # اسم يحمل البصمة: script.ab12cd34ef.js — فلا يمكن أن يختلط قديم بجديد على الاستضافة
    stem, ext = os.path.splitext(f)
    return '%s.%s%s' % (stem, fh[f], ext)
for f in assets:
    index = index.replace('"%s?h=__BID__"' % f, '"%s?h=%s"' % (hname(f), fh[f]))
h = hashlib.sha1()
for f in sorted(fh): h.update(f.encode()); h.update(fh[f].encode())
h.update(index.encode()); h.update(sw.encode())
bid = h.hexdigest()[:10]
index = index.replace('__BID__', bid)
core = ['./', './index.html', './manifest.json'] + ['./%s?h=%s' % (hname(f), fh[f]) for f in assets] + ['./' + f for f in STATIC]
soft = ['./' + f for f in SOFT]
swj = sw.replace('__BID__', bid).replace('__CORE__', json.dumps(core, ensure_ascii=False)).replace('__SOFT__', json.dumps(soft))
for old in glob.glob('a-*.html'): os.remove(old)
for f in assets:
    open(hname(f), 'wb').write(open(f, 'rb').read())
open('index.html', 'w', encoding='utf-8').write(index)
open('sw.js', 'w', encoding='utf-8').write(swj)
open('build.json', 'w').write(json.dumps({'b': bid, 'x': [['%s?h=%s' % (hname(f), fh[f]), os.path.getsize(f)] for f in assets]}))
open('version.json', 'w').write(json.dumps({'b': bid}))
print('BID', bid, 'assets', len(assets))

# حزمة النشر: ملفات مسطّحة بلا مجلدات. المصادر تُحفظ في dev-source.zip (ملف واحد) لمتابعة التطوير.
import zipfile, sys
if '--pack' in sys.argv:
    SRC = assets + ['dev-app.html', 'dev-build.py', 'dev-sw.template.js']
    with zipfile.ZipFile('dev-source.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for f in SRC: z.write(f)
    skip = set(assets) | {'dev-app.html', 'dev-build.py', 'dev-sw.template.js'}
    out = sys.argv[sys.argv.index('--pack') + 1]
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(os.listdir('.')):
            if os.path.isfile(f) and f not in skip and not f.endswith('.zip') or f == 'dev-source.zip':
                z.write(f)
