(function () {
    'use strict';
    var $ = function (i) { return document.getElementById(i); };
    var au, seek, box, state = 'idle', A = null, B = null, src = '', worker = null, wurl = null, iv = 0;
    function toast(m) { if (window.showToast)
        window.showToast(m); }
    function fmt(t) { t = Math.max(0, Math.round(t)); var m = Math.floor(t / 60), s = t % 60; return m + ':' + (s < 10 ? '0' : '') + s; }
    function dur() { return isFinite(au.duration) && au.duration > 0 ? au.duration : 0; }
    function isRtl() { return getComputedStyle(seek).direction === 'rtl'; }
    function build() {
        au = $('audio');
        seek = $('audioSeek');
        box = $('customAudio');
        if (!au || !seek || !box || $('abPanel'))
            return;
        box.style.position = 'relative';
        var tr = document.createElement('div');
        tr.id = 'abTrack';
        tr.innerHTML = '<i id="abSeg"></i><b id="abA"></b><b id="abB"></b>';
        seek.insertAdjacentElement('afterend', tr);
        var ov = document.createElement('div');
        ov.id = 'abCatch';
        ov.setAttribute('role', 'button');
        seek.insertAdjacentElement('afterend', ov);
        var p = document.createElement('div');
        p.id = 'abPanel';
        p.innerHTML = '<div class="controls"><button type="button" id="abStart">✂ تحديد مقطع</button></div><div id="abHint" class="mini"></div>' +
            '<div class="controls" id="abPick" style="display:none"><button type="button" id="abHereA">📍 من هنا</button><button type="button" id="abHereB">📍 إلى هنا</button><button type="button" id="abCancel">إلغاء</button></div>' +
            '<div class="controls" id="abActive" style="display:none"><button type="button" class="primary" id="abStop">⏹ إيقاف التكرار</button><button type="button" id="abEdit">✎ تعديل</button></div>';
        box.appendChild(p);
        $('abStart').onclick = begin;
        $('abCancel').onclick = cancel;
        $('abStop').onclick = function () { stopLoop(true); };
        $('abEdit').onclick = begin;
        $('abHereA').onclick = function () { setPoint(au.currentTime); };
        $('abHereB').onclick = function () { if (A === null) {
            toast('حدّد البداية أولًا');
            return;
        } setPoint(au.currentTime); };
        ov.addEventListener('click', function (e) {
            var d = dur();
            if (!d) {
                toast('شغّل التلاوة أولًا ثم حدّد المقطع');
                return;
            }
            var r = seek.getBoundingClientRect(), f = isRtl() ? (r.right - e.clientX) / r.width : (e.clientX - r.left) / r.width;
            setPoint(Math.max(0, Math.min(1, f)) * d);
        });
        ov.addEventListener('touchmove', function (e) { e.preventDefault(); }, { passive: false });
        render();
    }
    function begin() {
        if (!dur()) {
            toast('شغّل التلاوة أولًا ثم اضغط «تحديد مقطع»');
            return;
        }
        stopLoop(false);
        A = B = null;
        state = 'pickA';
        render();
    }
    function cancel() { stopLoop(false); A = B = null; state = 'idle'; stopTicker(); render(); }
    function setPoint(t) {
        var d = dur();
        t = Math.max(0, Math.min(d, t));
        if (state === 'pickA') {
            A = t;
            state = 'pickB';
            render();
            return;
        }
        if (state === 'pickB') {
            B = t;
            if (B < A) {
                var x = A;
                A = B;
                B = x;
            }
            if (B - A < 1) {
                toast('المقطع قصير جدًا؛ اختر نقطة أبعد (ثانية على الأقل)');
                B = null;
                return;
            }
            if (B > d - 0.25)
                B = d - 0.25;
            state = 'loop';
            render();
            try {
                au.currentTime = A;
                var pr = au.play();
                if (pr && pr.catch)
                    pr.catch(function () { });
            }
            catch (e) { }
            startTicker();
        }
    }
    function stopLoop(toastIt) {
        if (state === 'loop' && toastIt)
            toast('أُوقف تكرار المقطع');
        if (state === 'loop') {
            state = 'idle';
            A = B = null;
        }
        stopTicker();
        render();
    }
    function check() {
        if (state !== 'loop' || B === null || A === null)
            return;
        if (!au.paused && au.currentTime >= B - 0.05) {
            try {
                au.currentTime = A;
            }
            catch (e) { }
        }
    }
    function startTicker() {
        stopTicker();
        try {
            wurl = URL.createObjectURL(new Blob(['var t=setInterval(function(){postMessage(1)},60);onmessage=function(e){if(e.data==="stop"){clearInterval(t);close()}}'], { type: 'application/javascript' }));
            worker = new Worker(wurl);
            worker.onmessage = check;
        }
        catch (e) {
            worker = null;
            iv = setInterval(check, 250);
        }
    }
    function stopTicker() {
        if (worker) {
            try {
                worker.postMessage('stop');
                worker.terminate();
            }
            catch (e) { }
            worker = null;
        }
        if (wurl) {
            try {
                URL.revokeObjectURL(wurl);
            }
            catch (e) { }
            wurl = null;
        }
        if (iv) {
            clearInterval(iv);
            iv = 0;
        }
    }
    function pct(t) { var d = dur(); return d ? Math.max(0, Math.min(100, t / d * 100)) : 0; }
    function render() {
        if (!$('abPanel'))
            return;
        var rtl = isRtl(), side = rtl ? 'right' : 'left', tr = $('abTrack'), seg = $('abSeg'), ma = $('abA'), mb = $('abB');
        tr.style.cssText = 'left:' + seek.offsetLeft + 'px;top:' + seek.offsetTop + 'px;width:' + seek.offsetWidth + 'px;height:' + seek.offsetHeight + 'px';
        $('abCatch').style.cssText = 'left:' + seek.offsetLeft + 'px;top:' + (seek.offsetTop - 10) + 'px;width:' + seek.offsetWidth + 'px;height:' + (seek.offsetHeight + 20) + 'px;display:' + ((state === 'pickA' || state === 'pickB') ? 'block' : 'none');
        [seg, ma, mb].forEach(function (e) { e.style.left = e.style.right = ''; e.style.display = 'none'; });
        if (A !== null) {
            ma.style.display = 'block';
            ma.style[side] = pct(A) + '%';
            ma.textContent = 'A';
        }
        if (B !== null) {
            mb.style.display = 'block';
            mb.style[side] = pct(B) + '%';
            mb.textContent = 'B';
            seg.style.display = 'block';
            seg.style[side] = pct(A) + '%';
            seg.style.width = (pct(B) - pct(A)) + '%';
        }
        var hint = $('abHint');
        $('abStart').style.display = state === 'idle' ? '' : 'none';
        $('abPick').style.display = (state === 'pickA' || state === 'pickB') ? '' : 'none';
        $('abActive').style.display = state === 'loop' ? '' : 'none';
        $('abHereB').style.display = state === 'pickB' ? '' : 'none';
        $('abHereA').style.display = state === 'pickA' ? '' : 'none';
        hint.textContent = state === 'pickA' ? '① المس الشريط عند نقطة البداية' : state === 'pickB' ? '② المس الشريط عند نقطة النهاية (البداية ' + fmt(A) + ')' : state === 'loop' ? '🔁 تكرار من ' + fmt(A) + ' إلى ' + fmt(B) + ' — يستمر حتى تضغط إيقاف' : '';
    }
    function watch() {
        var s = au.currentSrc || au.src || '';
        if (src && s && s !== src && state !== 'idle') {
            state = 'idle';
            A = B = null;
            stopTicker();
        }
        src = s;
        render();
    }
    function boot() {
        build();
        if (!au)
            return;
        au.addEventListener('loadedmetadata', watch);
        au.addEventListener('emptied', function () { state = 'idle'; A = B = null; stopTicker(); render(); });
        au.addEventListener('play', function () { if (state === 'loop' && !worker && !iv)
            startTicker(); });
        au.addEventListener('timeupdate', check);
        document.addEventListener('visibilitychange', check);
        au.addEventListener('ended', function (e) {
            if (state !== 'loop' || A === null)
                return;
            e.stopImmediatePropagation();
            try {
                au.currentTime = A;
                var pr = au.play();
                if (pr && pr.catch)
                    pr.catch(function () { });
            }
            catch (x) { }
        }, true);
        au.addEventListener('seeked', render);
        window.addEventListener('resize', render);
        var _s = window.show;
        window.show = function (id) { var r = _s.apply(this, arguments); if (id === 'readerDetail')
            setTimeout(render, 80); return r; };
    }
    window.v107AB = { get: function () { return { state: state, A: A, B: B }; }, _set: setPoint, _begin: begin };
    if (document.readyState === 'loading')
        document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 500); });
    else
        setTimeout(boot, 500);
})();
